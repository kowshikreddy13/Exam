package com.mru;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TrainingExamApplication {

	public static void main(String[] args) {
		SpringApplication.run(TrainingExamApplication.class, args);
	}

}
